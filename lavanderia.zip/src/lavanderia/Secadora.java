package lavanderia;

public class Secadora {
	
	public void secar(Ropa unaPrenda) {
		System.out.println("La secadora seca una prenda");
		unaPrenda.setEstaSeca(true);
	}

}
