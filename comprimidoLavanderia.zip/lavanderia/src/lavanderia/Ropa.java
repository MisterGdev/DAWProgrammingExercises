package lavanderia;

public class Ropa {

	private final String talla;
	private String color;
	private boolean estaLimpia;
	private boolean estaSeca;
	
	public Ropa(String talla, String color) {
		this.talla = talla;
		this.color = color;
		estaLimpia = false;
		estaSeca = true;
		System.out.println("Esta prenda es de la talla " + talla + " y de color " + color);
	}
	
	//Setters y getters
	public String getTalla() {
		return talla;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
		System.out.println("Se ha teñido la ropa, ahora es de color " + color);
	}
	
	public boolean getEstaLimpia() {
		return estaLimpia;
	}
	
	public boolean getEstaSeca() {
		return estaSeca;
	}
	
	public void setEstaSeca(boolean estaSeca) {
		this.estaSeca = estaSeca;
		System.out.println("Una prenda pasa a estar seca o a estar mojada.");
	}
	
	public void setEstaLimpia(boolean estaLimpia) {
		this.estaLimpia = estaLimpia;
		System.out.println("Una prenda pasa a estar limpia.");
	}
}
