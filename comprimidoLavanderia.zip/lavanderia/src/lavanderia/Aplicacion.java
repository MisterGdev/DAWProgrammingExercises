package lavanderia;

import java.util.Scanner;

public class Aplicacion {
	
	private Operario unOperario;
	
	public Aplicacion() {
		
		Scanner teclado = new Scanner(System.in);
		
		Ropa unaPrenda = new Ropa("L","Blanco");
		unOperario = new Operario();
		
		
		System.out.println("¡Bienvenido a la lavanderia!");
		
		System.out.println("¿De que color quieres teñir tu ropa?");
		
		unOperario.cambiarColor(unaPrenda, "Rojo");
		
		unOperario.usarLavadora(unaPrenda);
		
		unOperario.usarSecadora(unaPrenda);
		
		
	}

	
	public static void main(String[] args) {
		Aplicacion unaApp = new Aplicacion();

	}

}
