package lavanderia;

public class Operario {
	
	private Ropa unaPrenda;
	private Lavadora unaLavadora;
	private Secadora unaSecadora;
	
	public Operario() {
		unaLavadora = new Lavadora();
		unaSecadora = new Secadora();
	}
	
	public void usarLavadora(Ropa unaPrenda) {
		unaLavadora.lavar(unaPrenda);
		System.out.println("El operario lava una prenda.");
	}
	
	public void usarSecadora(Ropa unaPrenda) {
		unaSecadora.secar(unaPrenda);
		System.out.println("El operario seca una prenda.");
	}
	
	public void cambiarColor(Ropa unaPrenda, String color) {
		unaPrenda.setColor(color);
		System.out.println("El operario tiñe una prenda.");
	}
}
