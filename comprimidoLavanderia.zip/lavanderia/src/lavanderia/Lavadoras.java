package lavanderia;

public class Lavadoras {

}
