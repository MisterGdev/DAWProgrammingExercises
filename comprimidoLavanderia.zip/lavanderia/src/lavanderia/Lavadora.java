package lavanderia;

public class Lavadora {

	public void lavar(Ropa unaPrenda) {
		unaPrenda.setEstaLimpia(true);
		unaPrenda.setEstaSeca(false);
		System.out.println("La lavadora lava una prenda.");
	}
}
