package lavanderia;

public class Secadora {

	public void secar(Ropa unaPrenda) {
		unaPrenda.setEstaSeca(true);
		System.out.println("La secadora seca una prenda.");
	}
}
